"""
Iris Flower Classification
---------------------------
Ek basic Machine Learning project jo Iris dataset ke upar
flower species predict karta hai (Setosa, Versicolor, Virginica)
sepal aur petal ke measurements se.

Model: Random Forest Classifier
"""

import pandas as pd
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns


def load_data():
    """Iris dataset load karo aur DataFrame me convert karo."""
    iris = load_iris()
    df = pd.DataFrame(iris.data, columns=iris.feature_names)
    df["species"] = iris.target
    df["species_name"] = df["species"].map(
        {i: name for i, name in enumerate(iris.target_names)}
    )
    return df, iris.target_names


def train_model(df):
    """Data ko train/test me split karke Random Forest train karo."""
    X = df.drop(columns=["species", "species_name"])
    y = df["species"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    return model, X_test, y_test


def evaluate_model(model, X_test, y_test, target_names):
    """Model ki accuracy aur report print karo."""
    y_pred = model.predict(X_test)

    acc = accuracy_score(y_test, y_pred)
    print(f"\n✅ Model Accuracy: {acc * 100:.2f}%\n")

    print("Classification Report:")
    print(classification_report(y_test, y_pred, target_names=target_names))

    # Confusion matrix plot save karo
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(6, 5))
    sns.heatmap(
        cm, annot=True, fmt="d", cmap="Blues",
        xticklabels=target_names, yticklabels=target_names
    )
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.title("Confusion Matrix - Iris Classification")
    plt.tight_layout()
    plt.savefig("confusion_matrix.png")
    print("📊 Confusion matrix 'confusion_matrix.png' me save ho gaya.")


def predict_sample(model, target_names):
    """Ek naya sample flower predict karke dikhao."""
    sample = [[5.1, 3.5, 1.4, 0.2]]  # sepal_length, sepal_width, petal_length, petal_width
    prediction = model.predict(sample)
    print(f"\n🌸 Sample flower {sample[0]} -> Predicted species: {target_names[prediction[0]]}")


if __name__ == "__main__":
    print("Iris Flower Classification Project shuru ho raha hai...\n")

    df, target_names = load_data()
    print("Dataset ka preview:")
    print(df.head())

    model, X_test, y_test = train_model(df)
    evaluate_model(model, X_test, y_test, target_names)
    predict_sample(model, target_names)
